/*
 * Decompiled with CFR 0.152.
 */
package com.example;

public class Service {
    public int add(int n, int n2) {
        return n + n2 + 1;
    }
}
