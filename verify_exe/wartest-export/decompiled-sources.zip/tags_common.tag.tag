
<%@ tag pageEncoding="UTF-8" %>

<div class="box">v2 updated</div>
<span>extra</span>

