/*
 * Decompiled with CFR 0.152.
 */
package org.apache.commons.lang3;

static class CharRange.1 {
}
