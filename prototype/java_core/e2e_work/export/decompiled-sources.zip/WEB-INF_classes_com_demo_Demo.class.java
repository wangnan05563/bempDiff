/*
 * Decompiled with CFR 0.152.
 */
package com.demo;

class Demo {
    private String name = "current";

    Demo() {
    }

    public String sayHello(String string) {
        if (string == null || string.trim().isEmpty()) {
            return "Hello, guest";
        }
        return "Hello, " + string.trim();
    }

    public int calc(int n, int n2) {
        return n * n2;
    }

    public boolean isAdmin(String string) {
        return "admin".equalsIgnoreCase(string);
    }
}
