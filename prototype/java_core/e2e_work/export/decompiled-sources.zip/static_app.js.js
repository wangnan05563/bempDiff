function validateForm(form) {
  var name = form.name.value;
  if (name.length === 0) {
    alert('name required'); return false;
  }
  return true;
}
